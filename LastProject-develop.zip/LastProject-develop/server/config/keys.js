module.exports={
	googleClientID : '635215189013-df6imknaqiet9h5lur4k0jo1mcrme9fu.apps.googleusercontent.com',
	googleClientSecret : 'DgBNWjCb8pyNSULHtOph4frU',
	mongoURI:'mongodb://deepak:deepak@ds239029.mlab.com:39029/finalyear',
	cookieKey:'sdguvdbhbshdbvhsdbhsbdvhbdsv',
	stripePublishableKey:'pk_test_h3jzLOQkC6ASPUhG9qc4VWyV',
	stripeSecretKey:'sk_test_F5K2GOSatKROewbXoBsFySqS',
	sendGridKey:'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'
}