# FinalProject


1.) Clone the develop branch onto your local.

2.) cd into the repo.

3.)cd into the server folder.

4.)run npm install.

5.)cd into the client folder (/server/client).

6.)run npm install.

7.)Do cd .. , so that you're back in the server directory.

8.)Type " npm run dev " , and press enter.
